﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;

namespace MyMiddleware.MyMiddlewares
{
    // You may need to install the Microsoft.AspNetCore.Http.Abstractions package into your project
    public class SaveUserInformation
    {
        private readonly RequestDelegate _next;

        public SaveUserInformation(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext httpContext)
        {
            var userinfo = httpContext.Request.Headers["user-agent"];
            string ip = httpContext.Connection.RemoteIpAddress.ToString();
            //---save data in DB
            await _next(httpContext);
        }
    }

    // Extension method used to add the middleware to the HTTP request pipeline.
    public static class SaveUserInformationExtensions
    {
        public static IApplicationBuilder UseSaveUserInformation(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<SaveUserInformation>();
        }
    }
}
