﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;

namespace MyMiddleware.MyMiddlewares
{
    // You may need to install the Microsoft.AspNetCore.Http.Abstractions package into your project
    public class ResponseEditingMiddleware
    {
        private readonly RequestDelegate _next;

        public ResponseEditingMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext httpContext)
        {

            await _next(httpContext);

            if (httpContext.Response.StatusCode==404)
            {
                await httpContext.Response.WriteAsync("Status Code is 404. This messege is from Response_Editing Middleware");
            }
        }
    }

    // Extension method used to add the middleware to the HTTP request pipeline.
    public static class ResponseEditingMiddlewareExtensions
    {
        public static IApplicationBuilder UseResponseEditingMiddleware(this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<ResponseEditingMiddleware>();
        }
    }
}
